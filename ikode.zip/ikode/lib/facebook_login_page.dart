import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';

class LogInPage extends StatefulWidget {
  @override
  _LogInPageState createState() => _LogInPageState();
}

class _LogInPageState extends State<LogInPage> {
  bool isLoggedIn = false;

  String data = "Guest";

  String imageUrl = "";
  String textIn = "Sign in with FaceBook";
  String textOut = "Sign Out";

  FacebookLogin fbLogIn;

  var profileData;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseUser user;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initAuth();
  }

  initAuth() {
    fbLogIn = FacebookLogin();
//    bool st = await fbLogIn.isLoggedIn;
//    print("usser $isLoggedIn");
//    updateUI(st);
  }

  _logout() {
    _auth.signOut().then((val) {
      fbLogIn.logOut();
    }, onError: print);

    updateUI();
    print("Logged out");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              height: 100.0,
              width: 100.0,
              decoration: BoxDecoration(shape: BoxShape.circle),
            ),
            Container(
              child: Text(
                data,
                style: TextStyle(color: Colors.black),
              ),
            ),
            GestureDetector(
              onTap: _auth == null ? initiateFaceBookLogin : _logout,
              child: Container(
                alignment: Alignment.center,
                height: 50.0,
                width: 200.0,
                child: Text(
                  _auth == null ? textIn : textOut,
                  style: TextStyle(color: Colors.white),
                ),
                decoration:
                    BoxDecoration(color: Color.fromRGBO(60, 90, 153, 1.0)),
              ),
            )
          ],
        ),
      ),
    );
  }

  initiateFaceBookLogin() async {
    fbLogIn
        .logInWithReadPermissions(["email", "public_profile"]).then((result) {
      switch (result.status) {
        case FacebookLoginStatus.loggedIn:
          final AuthCredential authCredential =
              FacebookAuthProvider.getCredential(
                  accessToken: result.accessToken.token);

          _auth.signInWithCredential(authCredential).then((user) {
            print(user.email);
          }).catchError(print);

          break;
        case FacebookLoginStatus.cancelledByUser:
          print("cancelled by user");
          break;
        case FacebookLoginStatus.error:
          print("error");
          break;
      }
    });
  }

  updateUI() {
    setState(() {});
  }
}
